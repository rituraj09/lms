<!-- ============================================================
     NAVIGATION
============================================================ -->
<nav class="nav" id="mainNav">
    <div class="nav-inner">

        <a href="{{ route('home') }}" class="nav-logo" onclick="showPage('home')">
            <img src="{{ asset('brand-logo/logo-alt/logo-text-right-bottom.png') }}" style="height:46px;width:auto"
                alt="MindShiksha">
        </a>
        <div class="nav-links">
            <a href="{{ route('home') }}" class="nav-link  {{ request()->routeIs('home') ? 'active' : '' }}">Home</a>

            <div class="nav-dropdown">
                <a href="#cognitive"
                    class="nav-link  {{ request()->routeIs('cognitive', 'life-skill') ? 'active' : '' }}">
                    Frameworks <i class="fas fa-chevron-down" style="font-size:0.65rem;margin-left:3px;"></i>
                </a>
                <div class="nav-dropdown-menu">
                    <a href="{{ route('cognitive') }}"
                        class="nav-dropdown-item {{ request()->routeIs('cognitive') ? 'active' : '' }}">
                        Cognitive Skill Framework
                    </a>
                    <a href="{{ route('life-skill') }}"
                        class="nav-dropdown-item  {{ request()->routeIs('life-skill') ? 'active' : '' }}">
                        Life Skill Framework
                    </a>
                    <a href="{{ route('leadership-skill') }}"
                        class="nav-dropdown-item  {{ request()->routeIs('leadership-skill') ? 'active' : '' }}">
                        Leadership Skill Framework
                    </a>
                </div>
            </div>

            <a href="{{ route('solutions') }}"
                class="nav-link  {{ request()->routeIs('solutions') ? 'active' : '' }}">Solutions</a>
            <a href="{{ route('use-cases') }}"
                class="nav-link {{ request()->routeIs('use-cases') ? 'active' : '' }}">For Whom</a>
            <a href="{{ route('about') }}"
                class="nav-link {{ request()->routeIs('about') ? 'active' : '' }}">About</a>
            <a href="{{ route('resources') }}"
                class="nav-link {{ request()->routeIs('resources') ? 'active' : '' }}">Resources</a>
            <a href="{{ route('contact') }}"
                class="nav-link {{ request()->routeIs('contact') ? 'active' : '' }}">Contact</a>
        </div>

        <div class="nav-actions">
            <a href="https://hub.mindshiksha.com/admin/login" class="btn btn-secondary demo-btn">
                <i class="fas fa-sign-in"></i>
                Login</a>
            <a href="{{ route('contact') }}" class="btn btn-primary demo-btn">
                <i class="fas fa-calendar-alt"></i>
                Request a Demo
            </a>
            <button class="hamburger" aria-label="Menu"><span></span><span></span><span></span></button>
        </div>
</nav>

<!-- Mobile Menu -->
<div class="mobile-menu" id="mobileMenu">
    <a href="{{ route('home') }}" class="mobile-nav-link" onclick="navigateTo('home');toggleMobileMenu()">Home</a>
    <a href="{{ route('cognitive') }}" class="mobile-nav-link" onclick="navigateTo('cognitive');toggleMobileMenu()">
        Cognitive Framework</a>
    <a href="{{ route('life-skill') }}" class="mobile-nav-link" onclick="navigateTo('lifeskill');toggleMobileMenu()">
        Life Skill Framework</a>
    <a href="{{ route('leadership-skill') }}" class="mobile-nav-link"
        onclick="navigateTo('lifeskill');toggleMobileMenu()">
        Leadership Skill Framework</a>
    <a href="{{ route('solutions') }}" class="mobile-nav-link" onclick="navigateTo('solutions');toggleMobileMenu()">
        Solutions</a>
    <a href="{{ route('use-cases') }}" class="mobile-nav-link" onclick="navigateTo('usecases');toggleMobileMenu()">
        For Whom</a>
    <a href="{{ route('about') }}" class="mobile-nav-link" onclick="navigateTo('about');toggleMobileMenu()">
        About</a>
    <a href="{{ route('resources') }}" class="mobile-nav-link" onclick="navigateTo('resources');toggleMobileMenu()">
        Resources</a>
    <a href="{{ route('contact') }}" class="mobile-nav-link" onclick="navigateTo('contact');toggleMobileMenu()">
        Contact</a>
    <div style="margin-top:1rem;">

        <a href="https://hub.mindshiksha.com/admin/login" class="btn btn-secondary  "
            style="width:100%;justify-content:center;">
            <i class="fas fa-sign-in"></i> Login
        </a>
        <button class="btn btn-primary" style="margin-top:10px;width:100%;justify-content:center;"
            onclick="navigateTo('contact');toggleMobileMenu()">
            <i class="fas fa-calendar-alt"></i> Request a Demo
        </button>
    </div>
</div>
