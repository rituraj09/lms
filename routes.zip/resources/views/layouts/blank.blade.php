<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'Document' }}</title>
    @livewireStyles
</head>

<body style="margin:0;padding:0;">
    {{ $slot }}
    @livewireScripts
</body>

</html>
